function openNav() {
    document.getElementById("mySidenav").style.width = "25%";
    document.getElementById("main").style.marginRight = "25%";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
    document.getElementById("mySidenav").style.backgroundColor = "rgba(17, 17, 17, 0.36)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "6%";
    document.getElementById("main").style.marginRight= "6%";
    document.body.style.backgroundColor = "white";
    document.getElementById("mySidenav").style.backgroundColor = "";
}